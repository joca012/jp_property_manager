LOGIN MODUL - Task System

Cilj:
- Samo zaključavanje aplikacije login-om.
- Još NE filtriramo podatke po user_id.
- Još NE uvodimo korisničke kategorije u postojeće ekrane.

FAJLOVI:
- auth.php
- login.php
- logout.php
- set_admin_password.php  (privremeno, obrisati posle upotrebe)
- .htaccess              (opciono, za Apache)

KORAK 1 - ubaci fajlove u root projekta
Kopiraj ove fajlove tamo gde su index.php i config.php.

KORAK 2 - podesi config.php za server
Na serveru podesi:
- host
- username
- password
- database

Primer:
$conn = new mysqli("localhost", "DB_USER", "DB_PASSWORD", "DB_NAME");

KORAK 3 - postavi admin lozinku
Otvori:
https://tvoj-domen/set_admin_password.php

Unesi lozinku.
Kada dobiješ poruku da je lozinka podešena, ODMAH OBRIŠI:
set_admin_password.php

KORAK 4 - zaštiti glavne fajlove
U svaki zaštićeni PHP fajl dodaj odmah posle:
include "config.php";

ovu liniju:
include "auth.php";

Ne dodaje se u:
- login.php
- logout.php
- config.php
- set_admin_password.php

Obavezno dodati u:
- index.php
- todo.php
- calendar.php
- mesecni_pregled.php
- godisnji_pregled.php
- planiraj.php
- izmeni.php
- zavrsi.php
- otkazi.php
- obrisi.php
- recycle.php
- restore.php
- spali.php
- sabloni.php
- smene.php
- generisi_smene.php
- update_task_time.php
- vrati.php

KORAK 5 - logout link
U header ili index dodaj link:
<a href="logout.php">Odjava</a>

NAPOMENA:
Ovo je samo zaštitni login sloj.
Svi prijavljeni korisnici i dalje vide sve taskove.
Prava R/W/D i korisničke kategorije rade se kasnije.
