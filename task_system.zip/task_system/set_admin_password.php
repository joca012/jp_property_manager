<?php
/* set_admin_password.php

   PRIVREMENI FAJL.
   1. Ubaci ga u projekat.
   2. Otvori ga jednom u browseru.
   3. Unesi novu lozinku za admin korisnika.
   4. Kada uspe, ODMAH OBRIŠI ovaj fajl sa servera.
*/

include "config.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';

    if (strlen($password) < 8) {
        $message = "Lozinka mora imati najmanje 8 karaktera.";
    } elseif ($password !== $password2) {
        $message = "Lozinke se ne poklapaju.";
    } else {

        $hash = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("
            UPDATE users
            SET password_hash = ?
            WHERE username = 'admin'
            LIMIT 1
        ");

        if ($stmt) {
            $stmt->bind_param("s", $hash);
            $stmt->execute();

            if ($stmt->affected_rows >= 0) {
                $message = "Lozinka je podešena. Sada obriši set_admin_password.php.";
            } else {
                $message = "Lozinka nije podešena.";
            }
        } else {
            $message = "Greška u pripremi SQL upita.";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Podešavanje admin lozinke</title>
</head>
<body style="font-family:Arial;padding:30px;">

<h2>Podešavanje admin lozinke</h2>

<?php if ($message): ?>
    <p><b><?= htmlspecialchars($message) ?></b></p>
<?php endif; ?>

<form method="POST">
    <label>Nova lozinka</label><br>
    <input type="password" name="password" required style="width:300px;padding:8px;">

    <br><br>

    <label>Ponovi lozinku</label><br>
    <input type="password" name="password2" required style="width:300px;padding:8px;">

    <br><br>

    <button type="submit">Sačuvaj lozinku</button>
</form>

</body>
</html>
