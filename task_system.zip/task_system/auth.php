<?php
/* auth.php
   Zaštitni sloj za sve stranice osim login.php, logout.php i config.php.
*/

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
